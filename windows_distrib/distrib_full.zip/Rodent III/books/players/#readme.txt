Books with names starting with ph- were made by Pawel Hase
and downloaded from http://www.chesspraga.cz/spikebook.htm

Books without such prefix were made by Pawel Koziol.